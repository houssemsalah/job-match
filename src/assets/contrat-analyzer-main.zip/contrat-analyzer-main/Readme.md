# Employment Contract Analyzing (Branch -> maxence-dev-branch)

# Changelog :
Integration of the template inside the current fork of the react app.
v.1.0.5


