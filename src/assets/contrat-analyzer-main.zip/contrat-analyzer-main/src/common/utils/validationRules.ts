import { validateProps } from "../../common/types";


export default function validate(values: validateProps) {
  let errors = {} as validateProps;

  if (!values.prenom) {
    errors.prenom = "Un prenom est requis";
  }
  if (!values.nom) {
    errors.nom = "Un nom est requis";
  }

  if (!values.email) {
    errors.email = "Une adresse email est requise";
  } else if (!/\S+@\S+\.\S+/.test(values.email)) {
    errors.email = "Email invalide";
  }

  if (!values.contrat) {
    errors.contrat = "Un contrat de type PDF ou DOCX est requis";
  }

  /* if (!values.message) {
    errors.message = "Un message est attendu";
  }  */
  return errors;
}
