import { useState } from "react";
import React from "react";
import { db, storage } from "../../firebase";
import { v4 as uuidv4 } from 'uuid';

export const useForm = (validate: any) => {
  const [progress, setProgress] = useState(0);
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [shouldSubmit, setShouldSubmit] = useState(false);
  const [disable, setDisable] = useState(false);
  const fileType = ["application/pdf"];

  const handleSubmit = (event: React.ChangeEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors(validate(values));
    if (values.prenom && values.nom && values.email && values.contrat) {
      db.collection("contrats")
        .add({
          ...values,
        })
        .then(() => {
          setShouldSubmit(true);
        });
    }
  };

  const handleUpload = (e) => {
    e.preventDefault();
    const files = e.target.files[0];

    if (files) {
      setErrors((errors) => ({ ...errors, contrat: "" }));
      setDisable(true);
      const fileRef = storage.ref(`files/${uuidv4()}_${files.name}`);

      const uploadTask = fileRef.put(files);
      uploadTask.on(
        "state_changed",
        (snapshot) => {
          const prog = Math.round(
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100
          );
          setProgress(prog);
        },
        (error) => console.log(error),
        () => {
          setValues((values) => ({ ...values, contrat: fileRef.fullPath }));
          setDisable(false);
        }
      );
    }
  };


  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.persist();

    setValues((values) => ({
      ...values,
      [event.target.name]: event.target.value,
    }));
    setErrors((errors) => ({ ...errors, [event.target.name]: "" }));
  };

  return {
    handleUpload,
    handleChange,
    handleSubmit,
    values,
    errors,
    progress,
    shouldSubmit,
    disable,
  };
};
