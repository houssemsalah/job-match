
import { Container, StyledInput } from "./styles";
import { Label } from "../TextArea/styles";
import { UploadProps } from "../types";

const Upload = ({ name, onChange }: UploadProps) => (
  <Container>
    <Label htmlFor={name}>{name}</Label>
    <StyledInput
      type="file"
      className="input"
      name={name}
      id={name}
      onChange={onChange}
    />
  </Container>
);

export default Upload;
