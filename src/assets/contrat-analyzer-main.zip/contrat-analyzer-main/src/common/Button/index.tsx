import { StyledButton } from "./styles";
import { ButtonProps } from "../types";

export const Button = ({
  color,
  fixedWidth,
  children,
  onClick,
  disabled,
}: ButtonProps) => (
  <StyledButton color={color} fixedWidth={fixedWidth} disabled={disabled} onClick={onClick}>
    {children}
  </StyledButton>
);
