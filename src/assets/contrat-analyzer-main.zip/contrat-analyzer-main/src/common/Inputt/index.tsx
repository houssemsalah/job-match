
import { StyledInput } from "./styles";
import { Label } from "../TextArea/styles";
import { InputProps } from "../types";

const Inputt = ({ name, placeholder, onChange, t }: InputProps) => (
  <div>
    <Label htmlFor={name}>{name}</Label>
    <StyledInput 
      placeholder={placeholder}
      name={name}
      id={name}
      onChange={onChange}
    />
  </div>
);

export default Inputt;
