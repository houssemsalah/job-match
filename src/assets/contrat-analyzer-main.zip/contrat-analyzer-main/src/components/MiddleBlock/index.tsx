import Upload from "../../common/Input/Upload";
import { MiddleBlockSection, Content, ContentWrapper } from "./styles";
import { Row, Col } from "antd";

import { Slide, Zoom } from "react-awesome-reveal";
import { ValidationTypeProps } from "./../ContactForm/types";
import { useForm } from "../../common/utils/useForm";
import validate from "../../common/utils/validationRules";
import { Button } from "../../common/Button";
import Input from "../../common/Input";
import Container from "../../common/Container";
import Inputt from "../../common/Inputt";
import TextArea from "../../common/TextArea";

import {
  ContactContainer,
  FormGroup,
  Span,
  ButtonContainer,
} from "./../ContactForm/styles";

interface MiddleBlockProps {
  title: string;
  content: string;
  button: string;
  t: any;
  id: string;
}

const MiddleBlock = ({ title, content, button, t, id }: MiddleBlockProps) => {

  const scrollTo = (id: string) => {
    const element = document.getElementById(id) as HTMLDivElement;
    element.scrollIntoView({
      behavior: "smooth",
    });
  };

  const {
    values,
    errors,
    handleChange,
    handleSubmit,
    shouldSubmit,
    handleUpload,
    disable,
  } = useForm(validate) as any;

  const ValidationType = ({ type }: ValidationTypeProps) => {
    const ErrorMessage = errors[type];
    return (
      <Zoom direction="left">
        <Span erros={errors[type]}>{ErrorMessage}</Span>
      </Zoom>
    );
  };

  /*   const handle = (e) => {
    e.preventDefault();
    uploadFiles();

    handleSubmit(e);
  };
 */
  return (
    <div>
      {shouldSubmit == false ? (
        <div>
          <Slide direction="left" style={{ marginTop: "-50px" }}>
            <MiddleBlockSection style={{ marginBottom: "-150px" }}>
              <Row justify="center" align="middle" id={id}>
                <ContentWrapper>
                  <Col >
                    <h6>{title}</h6>
                    <Content>{content}</Content>
                  </Col>
                </ContentWrapper>
              </Row>
            </MiddleBlockSection>
            <ContactContainer id={id}>
              <Row justify="center" align="middle">
                <Col lg={12} md={12} sm={24} xs={24}>
                  <FormGroup
                    autoComplete="off"
                    onSubmit={handleSubmit}
                    style={{ }}
                  >
                    <Col span={24}>
                      <Row>
                        <Col span={11}>
                          <Inputt
                            type="text"
                            // Customize the label here
                            name="prenom"
                            placeholder="Votre prenom"
                            value={values.name || ""}
                            onChange={handleChange}
                          />

                          <ValidationType type="prenom" />
                        </Col>
                        <Col span={1}></Col>
                        <Col span={12}>
                          <Inputt
                            type="text"
                            // Customize the label here
                            name="nom"
                            placeholder="Votre Nom"
                            value={values.name || ""}
                            onChange={handleChange}
                          />
                          <ValidationType type="nom" />
                        </Col>
                      </Row>
                    </Col>
                    <Col span={24}>
                      <Input
                        type="text"
                        name="email"
                        placeholder="Votre Email"
                        value={values.email || ""}
                        onChange={handleChange}
                      />
                      <ValidationType type="email" />
                    </Col>
                    <Col span={24}>
                      <Upload
                        name="Contrat"
                        value={values.contrat || ""}
                        onChange={handleUpload}
                      />
                      {/* { progress ? <p>{progress}%</p>  : */}
                      <ValidationType type="contrat" />
                    </Col>

                    <Col span={24}>
                      <TextArea
                        placeholder="Votre Message"
                        value={values.message || ""}
                        name="message"
                        onChange={handleChange}
                      />
                      <ValidationType type="message" />
                    </Col>

                    <ButtonContainer >
                      {/* Customize the submit button text here */}
                      <Button name="submit" disabled={disable} onClick= {()=>{scrollTo("intro")}}>
                        {"Envoyer"}
                      </Button>
                    </ButtonContainer>
                  </FormGroup>
                </Col>
              </Row>
            </ContactContainer>
          </Slide>
        </div>
      ) : (
         <Zoom  >
         <div style={{ marginTop: "50px" }} id={id}>
            <Container border="10"  >
           
              <Row style={{ paddingTop: "20px", paddingLeft: "150px" }}>
                {" "}
                <h2 style={{ display: "flex" }}>
                  Bravo{" "}
                  <h5
                    style={{
                      paddingLeft: "20px",
                      paddingTop: "20px",
                      fontSize: "30px",
                    }}
                  >
                    {" "}
                    Votre contrat a été téléchargé!
                  </h5>{" "}
                </h2>{" "}
              </Row>
              <p style={{ textAlign: "center" }}>
                Merci pour votre confiance. Nous revenons vers vous dans les plus brefs délais avec l'analyse de votre contrat.
              </p>
            </Container>
          </div>
        </Zoom> 
      )}
    </div>
  );
};

export default MiddleBlock;
