import firebase from "firebase/app";
import "firebase/storage";
import "firebase/firestore";


const firebaseConfig ={ 
    apiKey: "AIzaSyBCv1FT2leOtF8U-v1hJo4gPJYl58pD9ik",
  authDomain: "contrat-analyzer.firebaseapp.com",
  projectId: "contrat-analyzer",
  storageBucket: "contrat-analyzer.appspot.com",
  messagingSenderId: "794807256819",
  appId: "1:794807256819:web:4efcb80555f7c137c35986",
  measurementId: "G-BLQJJ8ZQ4D"
}

    firebase.initializeApp(firebaseConfig)

const storage = firebase.storage();
const db = firebase.firestore();


export { storage, db,firebase as default };